from odoo import api, fields, models, _
from odoo.exceptions import UserError


class SaleDetails(models.TransientModel):
    _name = 'sale.details.wizard'
    _description = 'Sale Details Report'

    
